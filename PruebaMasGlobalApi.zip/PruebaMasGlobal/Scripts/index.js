﻿$(document).ready(function () {
    $("#tipcon").click(function () {
        $("#capaInformacion").load("tiposcont.html");
    });
    $("#emp").click(function () {
        $("#capaInformacion").load("empleados.html");
    });
});