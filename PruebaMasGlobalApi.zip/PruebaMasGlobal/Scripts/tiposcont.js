﻿$(document).ready(function () {
    var url = "api/tipocon/gettc?idTipo=0";
    $.get(url, function (data) {
        var info = "<table border='1'><tr><th class='tituloBig' colspan='3'>TIPOS DE CONTRATO</th></tr><tr><th>Id</th><th>Nombre</th><th>Valor</th></tr>";
        $.each(data, function (key, value) {
            info += "<tr><td>" + value["idTipoContrato"] + "</td><td>" + value["nomTipoContrato"] + "</td><td>" + value["idValTipoContrato"]["valor"] + "</td></tr>";
        });
        info += "</table>";
        $("#capaInformacion").html(info);
    }).error(function (err) {
        alert(err.responseJSON["Message"]);
    });
});