﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using PruebaMasGlobal.DataAccess;
using PruebaMasGlobal.Models;

namespace PruebaMasGlobal.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api/tipocon")]
    public class tipoContratoController : ApiController
    {
        [HttpGet]
        [Route("gettc")]
        public IHttpActionResult getTipoContratos(int idTipo)
        {
            return Ok(new TipoContratoDal().getTipoContrato(idTipo));
        }
        
    }
}
