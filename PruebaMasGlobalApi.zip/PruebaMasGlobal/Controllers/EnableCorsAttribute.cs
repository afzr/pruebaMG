﻿using System;

namespace PruebaMasGlobal.Controllers
{
    internal class EnableCorsAttribute : Attribute
    {
    }
}