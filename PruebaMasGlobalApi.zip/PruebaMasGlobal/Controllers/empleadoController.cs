﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using PruebaMasGlobal.Models;
using PruebaMasGlobal.DataAccess;

namespace PruebaMasGlobal.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api/empleado")]
    public class empleadoController : ApiController
    {
        [HttpGet]
        [Route("getemp")]
        public IHttpActionResult getEmpleados(string cedula)
        {
            return Ok(new EmpleadoDal().getEmpleados(cedula));
        }
    }
}
