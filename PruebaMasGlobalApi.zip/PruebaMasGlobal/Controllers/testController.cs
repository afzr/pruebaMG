﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PruebaMasGlobal.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api/test")]
    public class testController : ApiController
    {   
        [HttpGet]
        [Route("test")]
        public IHttpActionResult getTest()
        {
            return Ok("Servicio Activo GET");
        }
        [HttpPost]
        public IHttpActionResult setTest()
        {
            return Ok("Servicio Activo POST");
        }
    }
}
