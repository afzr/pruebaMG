﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PruebaMasGlobal.Models;

namespace PruebaMasGlobal.DataAccess
{
    public class TipoContratoDal
    {
        List<TipoContrato> tiposContrato = new List<TipoContrato>(2);
        public TipoContratoDal()
        {
            tiposContrato.Add(new TipoContrato {
                idTipoContrato = 1,
                nomTipoContrato = "Mensual",
                idValTipoContrato = new valorTipoContratoDal().getValorTipoCont(2)
            });
            tiposContrato.Add(new TipoContrato
            {
                idTipoContrato = 2,
                nomTipoContrato = "Por Horas",
                idValTipoContrato = new valorTipoContratoDal().getValorTipoCont(1)
            });
        }
        public List<TipoContrato> getTipoContrato(int idTipo)
        {
            return idTipo == 0 ? tiposContrato : tiposContrato.GetRange(idTipo, 1);
        }

        
    }
}