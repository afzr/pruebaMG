﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PruebaMasGlobal.Models;

namespace PruebaMasGlobal.DataAccess
{
    public class EmpleadoDal
    {
        private List<Empleado> Empleados = new List<Empleado>(3);
        public EmpleadoDal()
        {
            Empleados.Add(new Empleado {
                cedula = "110",
                tipoDocumento = "CC",
                primerNombre = "Camilo",
                segundoNombre = "Jose",
                primerApellido = "Cardozo",
                segundoApellido = "Torres",
                estado = "A",
                tipoContrato = new TipoContratoDal().getTipoContrato(1)
            });
            Empleados.Add(new Empleado
            {
                cedula = "111",
                tipoDocumento = "CC",
                primerNombre = "Karen",
                segundoNombre = "Roxana",
                primerApellido = "Trujillo",
                segundoApellido = "Gomez",
                estado = "A",
                tipoContrato = new TipoContratoDal().getTipoContrato(1)
            });
            Empleados.Add(new Empleado
            {
                cedula = "112",
                tipoDocumento = "CC",
                primerNombre = "Sara",
                segundoNombre = "Sofia",
                primerApellido = "Buitrago",
                segundoApellido = "Rojas",
                estado = "A",
                tipoContrato = new TipoContratoDal().getTipoContrato(0)
            });
        }

        public List<Empleado> getEmpleados(string cedula)
        {
            //return string.IsNullOrEmpty(cedula) ? Empleados : new List<Empleado> { Empleados.Select(new Empleado(), x => x.cedula == cedula) };
            return string.IsNullOrEmpty(cedula) ? Empleados : Empleados.FindAll(
                delegate (Empleado current){
                    return current.cedula.Equals(cedula);
                });
        }
    }
}