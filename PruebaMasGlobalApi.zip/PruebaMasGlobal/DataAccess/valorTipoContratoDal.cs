﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PruebaMasGlobal.Models;

namespace PruebaMasGlobal.DataAccess
{
    public class valorTipoContratoDal
    {
        List<valorTipoContrato> ltsValTipoCon = new List<valorTipoContrato>(2);
        public valorTipoContratoDal()
        {
            ltsValTipoCon.Add(new valorTipoContrato {
                id = 1,
                valor = 22500
            });
            ltsValTipoCon.Add(new valorTipoContrato
            {
                id = 2,
                valor = 4500000
            });
        }

        public decimal getValTipoCont(int tipoCont)
        {
            var valorTipo= ltsValTipoCon.FindAll(
                delegate (valorTipoContrato current) {
                    return current.id.Equals(tipoCont);
                }).FirstOrDefault().valor;
            decimal valTipoCont = tipoCont == 1 ? 120 * valorTipo * 12 : valorTipo * 12;
            return valTipoCont;
        }

        public valorTipoContrato getValorTipoCont(int tipoCont)
        {
            return ltsValTipoCon.FindAll(
                delegate (valorTipoContrato current) {
                    return current.id.Equals(tipoCont);
                }).FirstOrDefault();
        }
    }
}