﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaMasGlobal.Models
{
    public class TipoContrato
    {
        public int idTipoContrato { get; set; }
        public string nomTipoContrato { get; set; }
        public valorTipoContrato idValTipoContrato { get; set; }
    }
}