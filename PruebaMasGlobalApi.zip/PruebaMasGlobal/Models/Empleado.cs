﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaMasGlobal.Models
{
    public class Empleado
    {
        public string cedula { get; set; }
        public string tipoDocumento { get; set; }
        public string primerNombre { get; set; }
        public string segundoNombre { get; set; }
        public string primerApellido { get; set; }
        public string segundoApellido { get; set; }
        public List<TipoContrato> tipoContrato { get; set; }
        public string estado { get; set; }
    }
}