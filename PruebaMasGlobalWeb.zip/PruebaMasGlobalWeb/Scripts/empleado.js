﻿$(document).ready(function () {
    var url = "http://localhost:4321/api/empleado/getemp?cedula=" + $("#txtEmpleado").val();
    $("#capaInformacion").html("<img src='imagenes/loader.gif' /><br><h4>Consultando Informacion</h4>");
    $.get(url, function (data) {
        var info = "";
        if (data != "") {
            info = "<table border='1'><tr><th class='tituloBig' colspan='7'>Empleados</th></tr></tr>";
            info += "<tr><th>Cedula</th><th>Primer Nombre</th><th>Segundo Nombre</th><th>Primer Apellido</th><th>Segundo Apellido</th>";
            info += "<th>Estado</th><th>Tipo Contrato (salario)</th></tr>";
            $.each(data, function (key, value) {
                info += "<tr><td>" + value["cedula"] + "</td>";
                info += "<td>" + value["primerNombre"] + "</td><td>" + value["segundoNombre"] + "</td>";
                info += "<td>" + value["primerApellido"] + "</td><td>" + value["segundoApellido"] + "</td>";
                info += "<td>" + value["estado"] + "</td><td>";
                $.each(value["tipoContrato"], function (key2, value2) {
                    info += "<li>" + value2["nomTipoContrato"] + " ($ " + value2["idValTipoContrato"]["valor"] + ")</li>";
                });
                info += "</td></tr>";
            });
            info += "</table>";
        }
        else
            info = "<h3>No se Encuentra el Empleado indicado</h3>";
        $("#capaInformacion").html(info);
    }).error(function (err) {
        alert(err.responseJSON["Message"]);
    });
});